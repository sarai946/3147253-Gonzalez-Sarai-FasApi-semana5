from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import User, Product, Favorite
from schemas import (
    UserRegister, UserLogin, UserResponse,
    Token, ProductCreate, ProductResponse,
    FavoriteResponse
)
from auth import (
    get_password_hash, verify_password,
    create_access_token, get_current_user,
    require_admin
)

# Crear tablas en la base de datos al iniciar
Base.metadata.create_all(bind=engine)

app = FastAPI(title="API con Autenticación - Semana 5")

# ----- REGISTRO -----
@app.post("/register", response_model=UserResponse)
def register(user: UserRegister, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(
        (User.username == user.username) | (User.email == user.email)
    ).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Usuario o email ya existen")
    hashed_pw = get_password_hash(user.password)
    new_user = User(username=user.username, email=user.email, hashed_password=hashed_pw)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

# ----- LOGIN -----
@app.post("/login", response_model=Token)
def login(user: UserLogin, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.username == user.username).first()
    if not db_user or not verify_password(user.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    token = create_access_token({"sub": db_user.username})
    return {"access_token": token, "token_type": "bearer"}

# ----- PERFIL -----
@app.get("/users/me", response_model=UserResponse)
def get_profile(current_user: User = Depends(get_current_user)):
    return current_user

# ----- ENDPOINT PROTEGIDO -----
@app.get("/protected")
def protected_route(current_user: User = Depends(get_current_user)):
    return {"message": f"Hola {current_user.username}, accediste a un endpoint protegido!"}

# ----- ADMIN: CREAR PRODUCTO -----
@app.post("/products", response_model=ProductResponse)
def create_product(
    prod: ProductCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    new_prod = Product(**prod.dict(), created_by=current_user.id)
    db.add(new_prod)
    db.commit()
    db.refresh(new_prod)
    return new_prod

@app.get("/products", response_model=list[ProductResponse])
def list_products(db: Session = Depends(get_db)):
    return db.query(Product).all()

# ----- FAVORITOS -----
@app.post("/favorites/{product_id}", response_model=FavoriteResponse)
def add_favorite(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    fav = Favorite(user_id=current_user.id, product_id=product.id)
    db.add(fav)
    db.commit()
    db.refresh(fav)
    return fav

@app.get("/favorites", response_model=list[FavoriteResponse])
def list_favorites(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return db.query(Favorite).filter(Favorite.user_id == current_user.id).all()

